-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 18, 2019 at 10:07 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `leve` int(25) NOT NULL AUTO_INCREMENT,
  `password` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  PRIMARY KEY (`leve`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`leve`, `password`, `username`) VALUES
(1, '12345', 'charles');

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE IF NOT EXISTS `candidate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `platform` varchar(255) NOT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `votecount` int(11) NOT NULL DEFAULT '0',
  `sy` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`id`, `position`, `name`, `platform`, `picture`, `votecount`, `sy`) VALUES
(4, 'President', 'Charles', 'Jubilee', 'Charles.png', 9, '35'),
(5, 'President', 'Uhuru', 'Jubilee', 'Uhuru.jpg', 3, '57'),
(6, 'President', 'Raila', 'NASA', 'Raila.jpg', 4, '69'),
(7, 'Vice_President', 'William', 'Jubilee', 'William.jpg', 4, '50'),
(8, 'Vice_President', 'Stephen', 'NASA', 'Stephen.jpg', 3, '57'),
(9, 'Vice_President', 'Ann', 'Cord', 'Ann.jpg', 6, '26'),
(11, 'Governor', 'Morrel', 'Jubilee', 'Morrel.jpeg', 6, '19'),
(12, 'Governor', 'Mzee', 'wiper', 'Mzee.jpg', 6, '70'),
(13, 'senator', 'Damaris', 'ODM', 'Damaris.jpg', 4, '44'),
(14, 'senator', 'Kelvin', 'Jubilee', 'Kelvin.jpg', 8, '20'),
(15, 'senator', 'Lucy', 'ODM', 'Lucy.jpg', 1, '32'),
(16, 'MPs', 'Maria', 'Cord', 'Maria.jpg', 2, '28'),
(17, 'MPs', 'Peter', 'NASA', 'Peter.jpg', 5, '55'),
(18, 'MPs', 'Onesmus', 'Jubilee', 'Onesmus.jpeg', 4, '39'),
(19, 'MPs', 'Robert', 'wiper', 'Robert.jpg', 3, '77'),
(21, 'MPs', 'Anastacia', 'ODM', 'Anastacia.jpg', 5, '39'),
(22, 'women_rep', 'Ruth', 'Cord', 'Ruth.jpg', 4, '50'),
(23, 'women_rep', 'Beauty', 'NASA', 'Beauty.jpg', 5, '20'),
(24, 'women_rep', 'Brenda', 'Jubilee', 'Brenda.jpg', 3, '21'),
(25, 'MCAs', 'Yule', 'wiper', 'Yule.jpg', 4, '25'),
(26, 'MCAs', 'James', 'Jubilee', 'James.jpg', 1, '25'),
(28, 'MCAs', 'Clare_', 'NASA', 'Clare_.jpg', 2, '20'),
(29, 'MCAs', 'Butter', 'wiper', 'Butter.jpg', 1, '22'),
(30, 'MCAs', 'John', 'Jubilee', 'John.jpg', 0, '27'),
(31, 'MCAs', 'Lady', 'ODM', 'Lady.jpg', 3, '20'),
(32, 'women_rep', 'Anastacia', 'Jubilee', 'Anastacia.jpg', 0, '31'),
(33, 'class_rep', 'martin', 'ODM', 'martin.jpg', 5, '39');

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE IF NOT EXISTS `position` (
  `position` varchar(50) NOT NULL,
  `IDNo` int(11) NOT NULL AUTO_INCREMENT,
  `Limit` int(11) NOT NULL,
  PRIMARY KEY (`IDNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`position`, `IDNo`, `Limit`) VALUES
('President', 1, 1),
('Vice_President', 2, 1),
('Governor', 3, 1),
('senator', 4, 1),
('MPs', 5, 2),
('women_rep', 6, 1),
('MCAs', 7, 2),
('class_rep', 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `studid` varchar(15) NOT NULL,
  `name` varchar(255) NOT NULL,
  `course` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `sec` varchar(20) NOT NULL,
  `password` varchar(15) DEFAULT NULL,
  `leve` varchar(10) NOT NULL DEFAULT '2',
  `sy` varchar(15) NOT NULL,
  PRIMARY KEY (`studid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`studid`, `name`, `course`, `year`, `sec`, `password`, `leve`, `sy`) VALUES
('11', 'Charles', 'Mbuvi', 'peter', 'Kisii', '11', '2', '2000_08_08'),
('111', 'Damaris', 'Ann', 'Gachega', 'Nyandarua', '111', '2', '1988-05-15'),
('1111', 'Ruth', 'Mumbi', 'Mulwa', 'Machakos', '1111', '2', '1978-08-11'),
('22', 'Uhuru', 'Muigai', 'Kenyatta', 'Kiambu', '22', '2', '1963-10-20'),
('222', 'Kelvin', 'Fisi', 'Mkubwa', 'Nyeri', '222', '2', '1997-05-15'),
('2222', 'Beauty', 'Sijui', 'Nani', 'Meru', '2222', '2', '1999-05-14'),
('23232123', 'ERIC', 'MUTUKU', 'MUTUKU', 'Mombasa', '123456', '2', '30/07/1990'),
('29003169', 'Nelson', 'Mwaniki', 'Muatha', 'Machakos', 'nelson.1234!', '2', '2019-05-01'),
('302134', 'vanessa', 'wambui', 'waithera', 'Mombasa', 'vanessa', '2', '16/1/2001'),
('33', 'Raila', 'Omolo', 'Odinga', 'Kisumu', '33', '2', '1958-11-18'),
('333', 'Lucy', 'Bahati', 'Wechizi', 'Mombasa', '333', '2', '1971-05-15'),
('3333', 'Brenda', 'Adhiambo', 'Omari', 'Kisumu', '3333', '2', '1999-07-15'),
('36924290', 'boniface', 'kitheka', 'kasamba', 'Machakos', 'kitheka98', '2', ''),
('37903846', 'Whitney', 'Njeri', 'Kingori', 'Kajiado', 'whitkin', '2', '24/12/2001'),
('44', 'William', 'Samoei', 'Ruto', 'Bomet', '44', '2', '1985-06-12'),
('444', 'Maria', 'Wa', 'Njugu', 'Nyeri', '444', '2', '1979-05-21'),
('4444', 'Yule', 'Mzungu', 'Fulani', 'Kakamega', '4444', '2', '12/05/1971'),
('546769', 'joan', 'cherono', 'mutten', 'Nakuru', 'qwerty', '2', '16'),
('55', 'Stephen', 'Kalonzo', 'Musyoka', 'Kitui', '55', '2', '1968-10-16'),
('555', 'Peter', 'Bandi', 'Hujui', 'Taita-Taveta', '555', '2', '1958-05-23'),
('5555', 'James', 'Kijana', 'Mfupi', 'Makueni', '5555', '2', '12/11/1997'),
('555555', 'martin', 'kyalo', 'kyalo', 'Turkana', 'qwerty', '2', '12/05/1971'),
('56789023', 'Zamzam', 'Moha', 'Jimale', 'Wajir', 'zam', '2', ''),
('66', 'Ann', 'Waiguru', 'Njue', 'Kakamega', '66', '2', '1995-10-02'),
('666', 'Onesmus', 'Muthure', 'Wanjuge', 'Narok', '666', '2', '1993-05-22'),
('6666', 'Clare ', 'Lilian', 'Mbaya', 'Mandera', '6666', '2', '12/05/1971'),
('667766', 'Mimi', 'MI', 'Me', 'Kisumu', '667766', '2', '27/12/2003'),
('77', 'Dorothy', 'Mutua', 'Kasee', 'Machakos', '77', '2', '1982-03-29'),
('777', 'Robert', 'Peterson', 'Omondi', 'Homa Bay', '777', '2', '1980-05-30'),
('7777', 'Butter', 'cup', 'Kevo', 'Kilifi', '7777', '2', '29/07/1999'),
('88', 'Morrel', 'Wa', 'Pipu', 'Nairobi', '88', '2', '1999-05-19'),
('888', 'Bensom', 'Msomali', 'Jimale', 'Garissa', '888', '2', '1988-05-15'),
('8888', 'John', 'The', 'Baptist', 'Laikipia', '8888', '2', '08/04/1998'),
('9876', 'Anto', 'Kith', 'Msafi', 'Trans-Nzoia', '9876', '2', '02/07/2019'),
('99', 'Mzee', 'Kijana', 'Wamalwa', 'Busia', '99', '2', '1971-01-19'),
('999', 'Anastacia', 'Mucheri', 'Prisss', 'Kwale', '999', '2', '1983-05-23'),
('9999', 'Lady', 'Wa', 'Jamoh', 'Laikipia', '9999', '2', '30/06/1992');

-- --------------------------------------------------------

--
-- Table structure for table `votecount`
--

CREATE TABLE IF NOT EXISTS `votecount` (
  `StudID` varchar(15) NOT NULL,
  `Position` varchar(50) NOT NULL,
  `Result` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votecount`
--

INSERT INTO `votecount` (`StudID`, `Position`, `Result`) VALUES
('29003169', 'President', 1),
('29003169', 'Vice_President', 1),
('29003169', 'Governor', 1),
('29003169', 'senator', 1),
('29003169', 'MPs', 1),
('29003169', 'women_rep', 1),
('29003169', 'MCAs', 1),
('88', 'President', 1),
('88', 'Vice_President', 1),
('88', 'Governor', 1),
('88', 'senator', 1),
('88', 'MPs', 1),
('88', 'women_rep', 1),
('88', 'MCAs', 1),
('4444', 'President', 1),
('4444', 'Vice_President', 1),
('4444', 'Governor', 1),
('4444', 'senator', 1),
('4444', 'MPs', 1),
('4444', 'women_rep', 1),
('4444', 'MCAs', 1),
('666', 'President', 1),
('666', 'Vice_President', 1),
('666', 'Governor', 1),
('666', 'senator', 1),
('666', 'MPs', 1),
('666', 'women_rep', 1),
('666', 'MCAs', 1),
('999', 'President', 1),
('999', 'Vice_President', 1),
('999', 'Governor', 1),
('999', 'senator', 1),
('999', 'MPs', 1),
('999', 'women_rep', 1),
('3333', 'President', 1),
('3333', 'Vice_President', 1),
('3333', 'MCAs', 1),
('3333', 'women_rep', 1),
('3333', 'MPs', 1),
('3333', 'senator', 1),
('3333', 'Governor', 1),
('12345678', 'President', 1),
('12345678', 'Vice_President', 1),
('12345678', 'Governor', 1),
('12345678', 'senator', 1),
('12345678', 'MPs', 1),
('12345678', 'women_rep', 1),
('12345678', 'MCAs', 1),
('555555', 'class_rep', 1),
('555555', 'President', 1),
('302134', 'President', 1),
('302134', 'Vice_President', 1),
('302134', 'Governor', 1),
('302134', 'senator', 1),
('302134', 'MPs', 1),
('302134', 'women_rep', 1),
('302134', 'MCAs', 1),
('302134', 'class_rep', 1),
('37903846', 'President', 1),
('37903846', 'Vice_President', 1),
('37903846', 'Governor', 1),
('37903846', 'senator', 1),
('37903846', 'MPs', 1),
('37903846', 'women_rep', 1),
('37903846', 'MCAs', 1),
('37903846', 'class_rep', 1),
('667766', 'President', 1),
('667766', 'Vice_President', 1),
('667766', 'Governor', 1),
('667766', 'senator', 1),
('667766', 'MPs', 1),
('667766', 'women_rep', 1),
('667766', 'MCAs', 1),
('667766', 'class_rep', 1),
('5555', 'President', 1),
('5555', 'Vice_President', 1),
('5555', 'Governor', 1),
('5555', 'senator', 1),
('5555', 'MPs', 1),
('5555', 'women_rep', 1),
('5555', 'MCAs', 1),
('5555', 'class_rep', 1),
('36924290', 'President', 1),
('36924290', 'Vice_President', 1),
('36924290', 'Governor', 1),
('36924290', 'senator', 1),
('36924290', 'MPs', 1),
('36924290', 'women_rep', 1),
('36924290', 'MCAs', 1),
('9876', 'President', 1),
('23232123', 'President', 1),
('23232123', 'Governor', 1),
('23232123', 'senator', 1),
('10587336', 'President', 1),
('10587336', 'Vice_President', 1),
('10587336', 'Governor', 1);
